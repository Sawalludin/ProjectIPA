<?php $__env->startSection('content'); ?>
<H4 style="text-align: center; margin-top: 50px;" >Currency</H4>
<table class="highlight" style="width: 80%; margin: auto; cursor: pointer;">
	<thead>
		<tr>
			<th>Code</th>
			<th>Name</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach($data as $key): ?>
		<tr>
			<td><?php echo e($key->code); ?></td>
			<td><?php echo e($key->name); ?></td>
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>