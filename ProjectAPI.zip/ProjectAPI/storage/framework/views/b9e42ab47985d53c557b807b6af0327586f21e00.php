<?php $__env->startSection('content'); ?>
<a class="waves-effect waves-light btn" style="float: right;" href="<?php echo e(url('/airline/flight')); ?>"><i class="material-icons right">library_add</i>Reservasi</a>
<H4 style="text-align: center; margin-top: 50px;" >Airport</H4>
<table class="highlight" style="width: 80%; margin: auto; cursor: pointer;">
	<thead>
		<tr>
			<th>Airport Name (Code)</th>
			<th>Location Name </th>
			<th>Country ID </th>
		</tr>
	</thead>
	<tbody>
		<?php foreach($data as $key): ?>
		<tr>
			<td><?php echo e($key->airport_name); ?> (<?php echo e($key->airport_code); ?>)</td>
			<td><?php echo e($key->location_name); ?></td>
			<td><?php echo e($key->country_id); ?></td>
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>