@extends('layouts.app')

@section('content')
<div class="tiket">API Project</div>
@endsection
<style type="text/css">
.tiket{
    font-family: sans-serif;
    font-size: 30pt;
    color: #3498db;
    text-align: center;
    margin-top: 50px;
}
.sh{
    font-family: sans-serif;
    font-size: 10pt;
    color: #3498db;
    text-align: center;
    margin-top: 10px;
}
</style>
