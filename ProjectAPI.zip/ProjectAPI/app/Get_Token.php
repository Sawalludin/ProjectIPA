<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Get_Token extends Model
{
    //
}
